import { ComingSoonPage } from "../coming-soon/ComingSoonPage";

export function AttendanceReportsPage() {
  return <ComingSoonPage title="Attendance Insights" />;
}
