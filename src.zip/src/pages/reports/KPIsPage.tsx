import { ComingSoonPage } from "../coming-soon/ComingSoonPage";

export function KPIsPage() {
  return <ComingSoonPage title="HR KPIs" />;
}
