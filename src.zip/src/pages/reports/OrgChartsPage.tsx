import { ComingSoonPage } from "../coming-soon/ComingSoonPage";

export function OrgChartsPage() {
  return <ComingSoonPage title="Org Charts" />;
}
