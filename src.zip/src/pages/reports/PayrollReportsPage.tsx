import { ComingSoonPage } from "../coming-soon/ComingSoonPage";

export function PayrollReportsPage() {
  return <ComingSoonPage title="Payroll Summary" />;
}
