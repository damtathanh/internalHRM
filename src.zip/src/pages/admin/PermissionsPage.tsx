import { ComingSoonPage } from "../coming-soon/ComingSoonPage";

export function PermissionsPage() {
  return <ComingSoonPage title="Permissions" />;
}
