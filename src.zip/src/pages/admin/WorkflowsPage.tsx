import { ComingSoonPage } from "../coming-soon/ComingSoonPage";

export function WorkflowsPage() {
  return <ComingSoonPage title="Workflows" />;
}
