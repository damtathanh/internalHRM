import { ComingSoonPage } from "../coming-soon/ComingSoonPage";

export function MasterDataPage() {
  return <ComingSoonPage title="Master Data" />;
}
