import { ComingSoonPage } from "../coming-soon/ComingSoonPage";

export function OverviewPage() {
  return <ComingSoonPage title="Attendance Overview" />;
}
