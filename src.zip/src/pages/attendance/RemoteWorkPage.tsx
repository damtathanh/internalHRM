import { ComingSoonPage } from "../coming-soon/ComingSoonPage";

export function RemoteWorkPage() {
  return <ComingSoonPage title="Remote Work" />;
}
