import { ComingSoonPage } from "../coming-soon/ComingSoonPage";

export function OvertimePage() {
  return <ComingSoonPage title="Overtime" />;
}
