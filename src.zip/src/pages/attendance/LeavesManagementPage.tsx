import { ComingSoonPage } from "../coming-soon/ComingSoonPage";

export function LeavesManagementPage() {
  return <ComingSoonPage title="Leave Management" />;
}
