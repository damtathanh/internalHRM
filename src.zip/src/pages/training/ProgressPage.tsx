import { ComingSoonPage } from "../coming-soon/ComingSoonPage";

export function ProgressPage() {
  return <ComingSoonPage title="Progress Dashboard" />;
}
