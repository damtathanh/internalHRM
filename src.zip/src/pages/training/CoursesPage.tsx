import { ComingSoonPage } from "../coming-soon/ComingSoonPage";

export function CoursesPage() {
  return <ComingSoonPage title="Training Courses" />;
}
