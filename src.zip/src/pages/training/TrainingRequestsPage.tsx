import { ComingSoonPage } from "../coming-soon/ComingSoonPage";

export function TrainingRequestsPage() {
  return <ComingSoonPage title="Training Requests" />;
}
