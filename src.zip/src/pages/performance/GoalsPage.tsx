import { ComingSoonPage } from "../coming-soon/ComingSoonPage";

export function GoalsPage() {
  return <ComingSoonPage title="Goal Setting" />;
}
