import { ComingSoonPage } from "../coming-soon/ComingSoonPage";

export function ReviewsPage() {
  return <ComingSoonPage title="Reviews" />;
}
