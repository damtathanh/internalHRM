import { ComingSoonPage } from "../coming-soon/ComingSoonPage";

export function ReportsPage() {
  return <ComingSoonPage title="Performance Reports" />;
}
