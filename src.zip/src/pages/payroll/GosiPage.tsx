import { ComingSoonPage } from "../coming-soon/ComingSoonPage";

export function GosiPage() {
  return <ComingSoonPage title="GOSI Integration" />;
}
