import { ComingSoonPage } from "../coming-soon/ComingSoonPage";

export function PromotionsPage() {
  return <ComingSoonPage title="Promotions" />;
}
