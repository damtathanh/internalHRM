import { ComingSoonPage } from "../coming-soon/ComingSoonPage";

export function BonusesPage() {
  return <ComingSoonPage title="Annual Bonuses" />;
}
