import { ComingSoonPage } from "../coming-soon/ComingSoonPage";

export function AllowancesPage() {
  return <ComingSoonPage title="Allowances" />;
}
